import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
//import { first } from 'rxjs/operators';
//import{Storage} from '@ionic/storage'
import { CreateProvider } from '../../providers/create/create';
import { HomePage } from '../home/home';
//import { HomePage } from '../home/home';
/**
 * Generated class for the CreatTicketPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-creat-ticket',
  templateUrl: 'creat-ticket.html',
})
export class CreatTicketPage {

  ticket= { name:localStorage.getItem("name"), 
  email: localStorage.getItem("Email"),
 // username:'MbkAh6PNctUHXfQUYL9Q',
 // password:'x',
  status: 2,
  priority: 1, 
  description:"",
  subject:""
}

  
  constructor(public navCtrl: NavController, public navParams: NavParams , public creater:CreateProvider,) {
   
  }

  ionViewDidLoad() {
    //console.log('ionViewDidLoad CreatTicketPage');
    // this.name = localStorage.getItem("name");
    // this.email = localStorage.getItem("Email");
    //this.name = this.navParams.get("name");
    console.log(this.ticket);
   // console.log(this.ticket.name);
   // console.log(this.email);
  }
  id:any;
  btn_saveTicket(){
   // console.log(this.ticket);
    
    this.id=localStorage.getItem('id');
    console.log('id'+this.id);
    if(!this.id)
    {
      alert("ticket not created");
    }
    else{
      this.creater.createTicket(this.ticket).then((result) => {
       alert("ticket is created and ticket id is "+this.id)
       console.log("result by create"+result);
      
      console.log('id'+this.id);
       this.navCtrl.push(HomePage);
        
      }, (err) => {
        console.log(err);
      });
   
    }
    }
//   responseData : any;
//   signup(){
    
//     this.creater.postData(this.ticket).then((result) => {
//      this.responseData = result;
//      if(this.responseData.userData){
//      console.log(this.responseData);
//      localStorage.setItem('userData', JSON.stringify(this.responseData));
    
//      }
//      else{ console.log("User already exists"); }
//    }, (err) => {
//      // Error log
//    });

//  }
      
  }