import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreatTicketPage } from './creat-ticket';

@NgModule({
  declarations: [
    CreatTicketPage,
  ],
  imports: [
    IonicPageModule.forChild(CreatTicketPage),
  ],
})
export class CreatTicketPageModule {}
