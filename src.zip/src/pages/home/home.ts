import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import{Storage} from '@ionic/storage'
import { CreatTicketPage } from '../creat-ticket/creat-ticket';
//import { CreatTicketPage } from '../creat-ticket/creat-ticket';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage{

  name:string;
  key:string="";
  Email:string;
  keyEmail:string="Email";
  
  constructor(public navCtrl: NavController, 
  
    private storage : Storage){
           
  }
  ionViewDidLoad() {
    this.loadData(); 
    //console.log("this method call")
  }
  saveData(){
    this.storage.set(this.key,this.name);
    localStorage.setItem('name',this.name);
    localStorage.setItem('Email',this.Email);
    this.loadData();
    
  }
   
  loadData(){
   console.log(this.storage.get(this.keyEmail));
    this.storage.get(this.key).then((val) =>{
     if(val!=null){
      this.navCtrl.push(CreatTicketPage)
        //name:val,
     }
  
  });
}
}
//  this.storage.remove(this.key);
      //this.storage.get(this.key).then((val) => {
        //navCtrl.push(CreatTicketPage,{
         // item:this.key
          //ABCD
    // this.storage.get(this.keyEmail).then((Emailval) => {
    //       }); 
//     this.storage.get(this.key).then((val) => {
//       console.log("your username is ",val);
// });
          //});
 // });
 
//   this.storage.get(this.key).then((val) => {
//           console.log("your username is ",val);
//     });
//     this.storage.get(this.keyEmail).then((val) => {
//       console.log("your Email is ",val);
// });
//   }