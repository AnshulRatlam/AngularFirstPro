import { HttpClient, HttpHeaders, } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { Header } from 'ionic-angular';
//import { map } from 'rxjs/operators';
/*
  Generated class for the CreateProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class CreateProvider {
   //require: any;
  apiUrl = 'https://savingspoint.freshdesk.com';
  constructor(public http: HttpClient) {
    console.log('Hello CreateProvider Provider');
  }

    public createTicket(data) {
  alert("this call")
         
    const httpOptions = {
      headers: new HttpHeaders({
        "content-type": "application/json",
        "Authorization":"Basic TWJrQWg2UE5jdFVIWGZRVVlMOVE6WA==",
        
      })
    };
      alert(Promise);
    return new Promise((resolve, reject) => {
      //this.http.post(this.apiUrl+'/api/v2/tickets'+postData+ httpOptions, JSON.stringify(data))
      this.http.post<any>(this.apiUrl+'/api/v2/tickets/',JSON.stringify(data), httpOptions)
        .subscribe(res => {
          if(res.id!=null)
          {
          localStorage.setItem('id',res.id );
          resolve(res);
          }
          else{
            alert("Ticket Not Create")
          }
        }, (err) => {
          reject(err);
        });
      
    });
  }
}




////////////////
   // let postData =   { 
            //   "description": "Do Not Change", 
            // "subject": "Do Not Change Genrated by code.", 
            // "email": "rohitpatidar96@gmail.com", 
            // "name":"Rohit Patidar",
            // "priority": 1, 
            // "status": 2
              
            // }
       /////////////////////////////////
//      console.log(header);
      //public async postData(credentials, type): Promise<any> {
       // let headers = new HttpHeaders();
        //await this.http.post(apiUrl + type, JSON.stringify(credentials), { headers: headers }).toPromise();
   // }
  // return  this.http.post(this.apiUrl , JSON.stringify(data), { headers: header }).toPromise();
  //      console.log("clientbasicInfoId: ", user.ArrayOfResponse[0].clientbasicinfoid);
    //    localStorage.setItem('clientbasicInfoId', user.ArrayOfResponse[0].clientbasicinfoid);
      // localStorage.setItem('PIN',user.ArrayOfResponse[0].PIN);
       // localStorage.setItem('PIN','8969');
       
        
 
      //   console.log("PIN: ",user.ArrayOfResponse[0].PIN);
      //   console.log("UserName :",user.ArrayOfResponse[0].username);
      //   console.log("Password :",user.ArrayOfResponse[0].password);
       
      
      //  localStorage.setItem('usr', user.ArrayOfResponse[0].username);
      //  localStorage.setItem('pwd', user.ArrayOfResponse[0].password);
      //  // this.storage.get('userid').then((val)=>{console.log(val);});
       // console.log(this.storage.get('password'));
       //  this.storage.get('loginjsondata').then((val)=>{this.datafromStore=val});
       //  console.log(this.datafromStore);
     //return data;
  // };
 // }
  
  
  
  

// var http = require("https");

// var options = {
//   "method": "POST",
//   "hostname": "savingspoint.freshdesk.com",
//   "port": null,
//   "path": "/api/v2/tickets",
//   "headers": {
//     "content-type": "application/json",
//     "authorization": "Basic TWJrQWg2UE5jdFVIWGZRVVlMOVE6WA==",
//     "cache-control": "no-cache",
//     "postman-token": "d93bd960-0ecf-dd6a-c129-7bf2c85d0fda"
//   }
// };

// var req = http.request(options, function (res) {
//   var chunks = [];

//   res.on("data", function (chunk) {
//     chunks.push(chunk);
//   });

//   res.on("end", function () {
//     var body = Buffer.concat(chunks);
//     console.log(body.toString());
//   });
// });

// req.write(JSON.stringify({ description: 'Do Not Change',
//   subject: 'Do Not Change Genrated by Postman.',
//   email: 'rohitpatidar96@gmail.com',
//   name: 'Rohit Patidar',
//   priority: 1,
//   status: 2 }));
// req.end();



////////////////////////////////////

// let header = new HttpHeaders();
//      header =  header.set('Content-Type', 'text/plain').set('UserID', userid).set('Password', pass);
     

//      console.log(header);
 
//   return this.http.post<any>('http://localhost/savingspointapi/api/DistributorLogin/Login', '',
//   {
//   headers:header} ).pipe(map(user=>{
//     console.log(user);
//     console.log(user.Message);
//     if(user.Message === "Login Successful.")
//     {
//    console.log('Successfull Login');
//       localStorage.setItem('currentUser', JSON.stringify(user));
//     }
////////////////////////////////////////////
  //   return new Promise((resolve, reject) => {
  //     this.http.post(this.apiUrl+'/api/v2/tickets', JSON.stringify(data))
  //       .subscribe(res => {
  //         resolve(res);
  //       }, (err) => {
  //         reject(err);
  //       });
  //   });
  // }



